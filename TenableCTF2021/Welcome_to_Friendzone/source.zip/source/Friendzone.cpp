#include "Console.h"

int main() {
  Console* console = new Console();
  console->Open();
}
