#!/bin/bash
filecount=0
RANGE=50
while [ $filecount -lt 1000 ] ; do
    filesize=$RANDOM
    let "filesize %= $RANGE"
    filename=file${filecount}.$RANDOM
    base64 /dev/urandom | 
    head -c "$filesize" > $filename
    git add $filename
    git commit -m "$RANDOM - add file $filename"
    ((filecount++))
done

