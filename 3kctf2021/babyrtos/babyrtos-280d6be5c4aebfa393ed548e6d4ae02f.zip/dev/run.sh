#!/bin/bash
qemu-system-mipsel -M malta -m 32 -nographic -kernel ./a.out