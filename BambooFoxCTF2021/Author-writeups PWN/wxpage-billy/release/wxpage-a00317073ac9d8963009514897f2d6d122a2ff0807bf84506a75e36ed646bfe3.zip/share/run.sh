#!/bin/bash
exec 2>/dev/null
timeout -k 5 300 /home/chall/chall
